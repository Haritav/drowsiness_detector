# Dataset Instructions

## Download

Download the Drowsiness Detection Dataset from Kaggle:

**Link:** https://www.kaggle.com/datasets/dheerajperumandla/drowsiness-dataset

## Setup

After downloading, extract and place the folders like this:

```
dataset/
├── open_eye/      ← images of open eyes
└── closed_eye/    ← images of closed eyes
```

Place the `dataset/` folder in the **root of the project** (same level as `src/`).

## Dataset Info

| Property | Value |
|---|---|
| Classes | 2 (open_eye, closed_eye) |
| Total Images | ~7000 |
| Format | JPG/PNG |
| Source | Kaggle — Dheeraj Perumandla |

## Note

Due to size constraints, the dataset is not included in this repository.
Please download it directly from Kaggle using the link above.
